"""
Week 3: Python & Data Wrangling
Run: python week3_data_wrangling.py
Input: data.xlsx (same folder)
Output: Week3_Data_Wrangling_Submission.xlsx

Cleaning decisions are documented in the Data_Quality_Log sheet.
The inferred date and duration correction should be verified against the source if available.
"""
import pandas as pd
import numpy as np

INPUT_FILE = "data.xlsx"
OUTPUT_FILE = "Week3_Data_Wrangling_Submission.xlsx"

raw = pd.read_excel(INPUT_FILE)
clean = raw.copy()

# Normalize date strings, remove quote characters, and repair compact YYYYMMDD format.
clean["Date"] = clean["Date"].astype("string").str.strip().str.strip("'").str.strip('"')
clean["Date"] = clean["Date"].replace({"20201226": "2020/12/26"})
clean["Date"] = pd.to_datetime(clean["Date"], errors="coerce")

# Infer missing date from the surrounding daily sequence (Dec 21, Dec 23).
clean.loc[clean["Date"].isna(), "Date"] = pd.Timestamp("2020-12-22")

# Correct the obvious 450-minute duration anomaly to 45 minutes.
# Verify this assumption against the original source before treating it as definitive.
clean.loc[clean["Duration"] == 450, "Duration"] = 45

# Remove exact duplicates.
duplicates_removed = len(clean) - len(clean.drop_duplicates())
clean = clean.drop_duplicates().reset_index(drop=True)

# Fill missing Calories using the median of non-missing values.
calories_median = clean["Calories"].median()
clean["Calories"] = clean["Calories"].fillna(calories_median)

# Create new columns.
clean["Calories_per_minute"] = (clean["Calories"] / clean["Duration"]).round(2)
clean["Pulse_Category"] = np.select(
    [clean["Pulse"] < 100, clean["Pulse"] <= 110],
    ["Low (<100)", "Moderate (100–110)"],
    default="High (>110)"
)

# Filter records to durations from 30 to 120 minutes inclusive.
filtered = clean.loc[clean["Duration"].between(30, 120)].copy().reset_index(drop=True)

quality = pd.DataFrame([
    ["Rows in source dataset", len(raw), "Original input"],
    ["Missing Date values", int(raw["Date"].isna().sum()), "Inferred as 2020-12-22 from surrounding dates"],
    ["Missing Calories values", int(raw["Calories"].isna().sum()), f"Filled with median ({calories_median:.2f})"],
    ["Exact duplicate rows removed", duplicates_removed, "Kept first copy"],
    ["Duration value corrected", int((raw["Duration"] == 450).sum()), "450 changed to 45; verify against source"],
    ["Rows after cleaning", len(clean), "After duplicate removal and cleaning"],
    ["Rows after duration filter", len(filtered), "Duration between 30 and 120 minutes"],
], columns=["Check", "Count / Value", "Action / Notes"])

summary = pd.DataFrame({
    "Metric": ["Cleaned records", "Filtered records (Duration 30–120)", "Average Duration (min)",
               "Average Pulse", "Average Maxpulse", "Average Calories", "Total Calories",
               "Average Calories per minute"],
    "Value": [len(clean), len(filtered), round(clean["Duration"].mean(), 2),
              round(clean["Pulse"].mean(), 2), round(clean["Maxpulse"].mean(), 2),
              round(clean["Calories"].mean(), 2), round(clean["Calories"].sum(), 2),
              round(clean["Calories_per_minute"].mean(), 2)]
})
pulse_summary = clean.groupby("Pulse_Category").size().reset_index(name="Record_Count")

with pd.ExcelWriter(OUTPUT_FILE, engine="openpyxl") as writer:
    raw.to_excel(writer, sheet_name="Original_Data", index=False)
    clean.to_excel(writer, sheet_name="Cleaned_Data", index=False)
    filtered.to_excel(writer, sheet_name="Filtered_Data", index=False)
    quality.to_excel(writer, sheet_name="Data_Quality_Log", index=False)
    summary.to_excel(writer, sheet_name="Summary", index=False)
    pulse_summary.to_excel(writer, sheet_name="Pulse_Summary", index=False)

print(f"Saved {OUTPUT_FILE}")
