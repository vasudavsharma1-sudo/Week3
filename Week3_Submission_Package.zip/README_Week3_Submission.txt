WEEK 3 SUBMISSION — PYTHON & DATA WRANGLING

Files:
1. Week3_Data_Wrangling_Submission.xlsx — completed workbook and results.
2. week3_data_wrangling.py — reproducible pandas script.
3. data.xlsx — original supporting input file.

Workbook sheets:
- Original_Data: unchanged source data.
- Cleaned_Data: normalized dates, duplicate removed, missing Calories filled, derived columns added.
- Filtered_Data: only records with Duration between 30 and 120 minutes inclusive.
- Data_Quality_Log: every cleaning action and assumptions.
- Summary: key metrics and chart.
- Pulse_Summary: counts by pulse category.

Important assumptions:
- Missing date inferred as 2020-12-22 from the surrounding daily sequence.
- 20201226 converted to 2020-12-26.
- Duration 450 changed to 45 as a likely typo; verify against the original source if possible.
- Missing Calories filled with the median of available Calories values.
- Exact duplicate row removed after date normalization.
- Calories_per_minute = Calories / Duration.
- Pulse_Category: Low (<100), Moderate (100–110), High (>110).

To reproduce:
Install dependencies: pip install pandas openpyxl numpy
Keep data.xlsx and week3_data_wrangling.py in the same folder, then run:
python week3_data_wrangling.py
